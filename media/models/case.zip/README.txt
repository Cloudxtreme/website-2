Place the mesh texture in assets/minecraft/textures/blocks/mesh_clay_cyan.png

— CoderPythonX